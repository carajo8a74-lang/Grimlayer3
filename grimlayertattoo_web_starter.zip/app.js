// Simple i18n and form handler
const i18n = {
  en: JSON.parse(document.getElementById('i18n-en').textContent || '{}'),
  es: JSON.parse(document.getElementById('i18n-es').textContent || '{}'),
};

const setLang = (lang) => {
  const dict = i18n[lang] || {};
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) el.textContent = dict[key];
  });
  localStorage.setItem('lang', lang);
  document.documentElement.lang = lang;
};

document.getElementById('lang-en').addEventListener('click', () => setLang('en'));
document.getElementById('lang-es').addEventListener('click', () => setLang('es'));
document.getElementById('year').textContent = new Date().getFullYear();

// Preload user language
setLang(localStorage.getItem('lang') || (navigator.language?.startsWith('es') ? 'es' : 'en'));

// WhatsApp link
const wa = document.getElementById('whatsapp-link');
if (wa) {
  const phone = '13059155560'; // E.164 without '+' for wa link
  const text = encodeURIComponent('Hola, quiero consultar para un tatuaje. Mi idea: ');
  wa.href = `https://wa.me/${phone}?text=${text}`;
}

// Form opens default email client with prefilled body
document.getElementById('request-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const subject = encodeURIComponent('Tattoo Request — GrimLayerTattoo');
  const body = encodeURIComponent(`Name: ${data.name}\nEmail: ${data.email}\nIdea: ${data.idea}`);
  window.location.href = `mailto:booking@grimlayertattoo.com?subject=${subject}&body=${body}`;
});
