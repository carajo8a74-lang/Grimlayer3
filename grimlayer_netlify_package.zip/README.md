# GrimLayerTattoo — Netlify Package (Website + Deck)

Incluye: sitio estático bilingüe + Admin (Decap CMS) + Deck /deck/ siguiendo el prompt.
Despliegue: Import from Git en Netlify; Identity + Git Gateway; entrar a /admin/.
Generado 2025-09-01
