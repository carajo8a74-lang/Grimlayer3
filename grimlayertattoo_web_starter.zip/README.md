# GrimLayerTattoo — Web Starter (Static, Netlify-ready)

## What you have
- Clean static site (HTML/CSS/JS), **no frameworks** needed.
- Bilingual **EN/ES** toggle with JSON dictionaries.
- Booking CTA: mailto and WhatsApp, plus deposit info (Zelle/Cash App).
- Aftercare section (membrane 7 days), no image-use clause.
- SEO basics: titles, meta, `sitemap.xml`, `robots.txt`, `manifest.webmanifest`, `favicon`.
- `netlify.toml` with headers + www→root redirect.

## Quick start on iMac (clean slate)
1. **Unzip** and open the folder.
2. Double click `index.html` to preview locally.
3. When ready, login to **Netlify** → **Add new site** → **Deploy manually** → Drag & drop the folder.
4. Set the site name (temporary), then attach your domain:
   - In Netlify: **Site settings → Domain management → Add domain** → `grimlayertattoo.com`.
   - In Namecheap: `Advanced DNS` → Add **A record**: host `@` → value **Netlify load balancer IPs** (Netlify UI will show them) or use **CNAME** to Netlify subdomain if offered.
   - Add `CNAME` for `www` → Netlify subdomain (e.g., `your-site.netlify.app`).
5. **Enforce HTTPS** in Netlify: Enable **Automatic HTTPS** and **Force HTTPS**.

## Replace placeholders
- Swap `/assets/img/placeholder-*.jpg` with your real photos (same names or update `index.html`).
- Edit copy in `/i18n/en.json` and `/i18n/es.json`.
- Update contact email in `index.html` if needed.

## Next steps (optional)
- Hook a real booking system (custom or Calendly-like), or integrate Netlify Forms.
- Add analytics (e.g., Plausible/GA4).
- Optimize images (webp) and add structured data (LocalBusiness).

— Built for Luis (@grimlayertattoo) — 2025-09-01
